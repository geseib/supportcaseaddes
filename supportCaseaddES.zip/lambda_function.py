import json
import boto3
import time
import os

clientorg = boto3.client('organizations')
clientsupport = boto3.client('support')

def lambda_handler(event, context):
    
    print (event)
    create_account_id = event['detail']['responseElements']['createAccountStatus']['id']
    account_status = 'IN_PROGRESS'
    while account_status == 'IN_PROGRESS':
        time.sleep(10)
        create_account_status_response = clientorg.describe_create_account_status(
            CreateAccountRequestId=create_account_id)
        print("Create account status "+str(create_account_status_response))
        account_status = create_account_status_response.get('CreateAccountStatus').get('State')
    if account_status == 'SUCCEEDED':
        account_id = create_account_status_response.get('CreateAccountStatus').get('AccountId')
        account_name = create_account_status_response.get('CreateAccountStatus').get('AccountName')
    elif account_status == 'FAILED':
        print("Account creation failed: " + create_account_status_response.get('CreateAccountStatus').get('FailureReason') + "Support case not created.")
        sys.exit(1)
    
    #case variables    
    customerName = os.environ['customerName']
    caseSubject="Add account to Basic Support"
    caseSeverityCode='low'
    caseCategoryCode='other-account-issues'
    caseServiceCode='customer-account'
    caseCommunicationBody = "Hi AWS, please add account number "+ account_id + " to basic support under this payer account"
    caseCCEmailAddresses=os.environ['ccEmailAddresses']
    caseIssueType='customer-service'
    
    #Create Case
    response = clientsupport.create_case(
        subject= caseSubject,
        severityCode=caseSeverityCode,
        categoryCode=caseCategoryCode,
        serviceCode=caseServiceCode,
        communicationBody=caseCommunicationBody,
        ccEmailAddresses=[caseCCEmailAddresses],
        language='en',
        issueType=caseIssueType
    )
    
    #Print Case ID to return
    caseId = response['caseId']
    case = clientsupport.describe_cases(
        caseIdList=[caseId])
    displayId = case['cases'][0]['displayId']
    print ("Support case: " + displayId + " created.")
    return ("Case " + displayId + " opened")

   
